function setup() {
  createCanvas(330, 400);
}

function draw() {
  background(220);
  strokeWeight(3);
  fill(247, 188, 146);
  ellipse(160,170,200,250);
  triangle (150,150,150,200,130,200);
  fill(255, 255, 255);
  ellipse(110,150,40,20);
  ellipse(200,150,40,20);
  fill(56, 33, 16);
  ellipse(200,150,20,19);
  ellipse(110,150,20,19);
  fill(247,134,134);
  ellipse(150,230,50,25);
  fill(48, 37, 29);
  rect(50,90,40,300);
  rect(70,70,40,70);
  rect(90,60,40,70);
  rect(110,50,40,70);
  rect(130,45,40,70);
  rect(150,45,40,70);
  rect(170,50,40,70);
  rect(190,60,40,70);
  rect(220,80,40,300);
}